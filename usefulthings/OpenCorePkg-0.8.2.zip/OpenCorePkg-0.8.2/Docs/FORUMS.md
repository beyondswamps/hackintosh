## OpenCore Discussion Forums

- AppleLife.ru in Russian:
  - [Development](https://applelife.ru/threads/razrabotka-opencore.2943955)
  - [Discussion](https://applelife.ru/threads/opencore-obsuzhdenie-i-ustanovka.2944066/)
  - [Icon sets](https://applelife.ru/threads/kastomizacija-opencanopy.2945020/)
- [Hackintosh-Forum.de](https://www.hackintosh-forum.de/forum/thread/42353-opencore-bootloader) in German
- InsanelyMac.com in English:
  - [Development](https://www.insanelymac.com/forum/topic/338527-opencore-development/)
  - [Discussion](https://www.insanelymac.com/forum/topic/338516-opencore-discussion/)
  - [Icon sets](https://www.insanelymac.com/forum/topic/344251-opencanopy-icons/)
- MacRumors.com in English:
  - [Big Sur on Unsupported Macs](https://forums.macrumors.com/threads/macos-11-big-sur-on-unsupported-macs-thread.2242172/)
  - [Monterey on Unsupported Macs](https://forums.macrumors.com/threads/macos-12-monterey-on-unsupported-macs-thread.2299557/)
  - [OpenCore on the MacPro](https://forums.macrumors.com/threads/opencore-on-the-mac-pro.2207814/)
- [macOS86.it](https://www.macos86.it/showthread.php?4570-OpenCore-aka-OC-Nuovo-BootLoader) in Italian
- [KVM-OpenCore](https://github.com/Leoyzen/KVM-Opencore) in English, KVM configuration
- [Reddit](https://www.reddit.com/r/hackintosh) in English
